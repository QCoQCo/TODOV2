import { useState,useEffect } from "react";
import axios from "axios";

const TaskTest=({userId})=>{
    // 유저 아이디별로 할일목록을 출력하려 했으나 userId를 백엔드로 옮기는 방법을 모름
    //SELECT * FROM tasks WHERE userId=(?)
    // 내일 다시시도

    return(
        <>
            rtews
        </>
    )
};

export default TaskTest;