//pages/taskManager/index.js
import TaskManager from "./TaskManager";
import TaskTest from "./TaskTest";

export {TaskManager,TaskTest};