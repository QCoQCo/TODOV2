const SignupComplete=()=>{
    return(
        <div className="account">
            <div className="account-inner">
                SignupComplete
            </div>
        </div>
    )
};

export default SignupComplete;