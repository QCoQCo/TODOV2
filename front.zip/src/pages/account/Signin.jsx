const Signin=()=>{
    return(
        <div className="account">
            <div className="account-inner">
                Signin
            </div>
        </div>
    )
};

export default Signin;