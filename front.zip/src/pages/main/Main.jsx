import { DbTest } from "../../components/main";

const Main=()=>{
    return(
        <div className="Main">
            <DbTest/>
        </div>
    )
};

export default Main;