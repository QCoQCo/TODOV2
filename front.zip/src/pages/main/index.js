//pages/main/index.js
import Main from "./Main";

export {Main};