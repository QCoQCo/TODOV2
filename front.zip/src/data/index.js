//data/index.js
import { AuthContext, AuthProvider } from "./AuthContext";

export{
    AuthContext,
    AuthProvider
};