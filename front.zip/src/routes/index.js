import AccountRoutes from "./AccountRoutes";

export {AccountRoutes};