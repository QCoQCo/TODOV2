//components/common/index.js
import Header from "./Header";
import Gnb from "./Gnb";
import Footer from "./Footer";


export {Header,Gnb,Footer};