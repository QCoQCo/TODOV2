//components/main/index.js

import DbTest from "./DbTest";

export {DbTest};